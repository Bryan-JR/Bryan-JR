api = 'https://www.datos.gov.co/resource/f527-xetw.json';
var datosJson;

getAll = async () => {
    try {
        const respuesta = await fetch(this.api);

        if(respuesta.status == 200){
            let json = await respuesta.json();
            return json;
        }
    } catch (e) {
        alert('Ocurrió un error: '+ e);
    }
}

getUno = async (matricula) => {
    try {
        const respuesta = await fetch(this.api+'?placa='+matricula);
        if(respuesta.status == 200){
            let json = await respuesta.json();
            return json;
        }
    } catch (error) {
        alert(error);
    }
}

const mostrarDatos = () => {
    try {
        const todos =  getAll().then(data => {
        datosJson = data;
        const divCont = document.getElementById("app");
        const element = document.createElement("div");
        element.className = "fila";

        let htmlTabla = `<table id="tablaDatos">
                <thead>
                    <tr>
                        <th scope="col">N°</th>
                        <th scope="col">Placa</th>
                        <th scope="col">Ciudad</th>
                        <th scope="col">Vigencia</th>
                        <th scope="col">Código</th>
                        <th scope="col">Descripción</th>
                        <th scope="col">+</th>
                    </tr>
                </thead>
                <tbody class="cuerpoTabla">`;
                data.forEach((element, index) => {
                    htmlTabla = htmlTabla + `
                    <tr>
                        <td scope="row" class="filaT">${index+1}</td>
                        <td class="filaT">${element.placa}</td>
                        <td class="filaT">${element.ciudad_inmovilizacion}</td>
                        <td class="filaT">${element.vigencia}</td>
                        <td class="filaT">${element.id_codigo}</td>
                        <td class="desc">${element.desc_infraccion}</td>
                        <td class="info"><div id="myInfo" class="icon" onclick="abrir(); mostrarInfo('${element.placa}');return false;"><i class="bi bi-info-lg"></i></div></td>
                    </tr>`; 
                });
                 htmlTabla = htmlTabla + `</tbody>
                </table>`;                    
               element.innerHTML = htmlTabla;
                divCont.appendChild(element);
    });
    } catch (error) {
        alert(error);
    }
};


const ventana = document.getElementById("informacion");
const abrir = () => {
    ventana.classList.remove('dos');
    ventana.className = ('uno');
};
const mostrarInfo = (matricula) => {
    try {
        const todos = getUno(matricula).then(dato => {
            datosJson = dato;
            let cont = document.getElementById("contendorInfo");
            

            let textoHTML = `   <a href="#app" class="salir" id="salir" onclick="cerrar();"><i class="bi bi-x-lg"></i></a>
                                    <h2>Información de inmovilización</h2>
                                    <div class="cuadros">
                                    <div><h3>Matricula: </h3><p>${dato[0].placa}</p></div>
                                    <div><h3>Ciudad: </h3><p>${dato[0].ciudad_inmovilizacion}</p></div>
                                    <div><h3>Fecha de Vigencia: </h3><p>${dato[0].vigencia}</p></div>
                                    <div><h3>Código: </h3><p>${dato[0].id_codigo}</p></div>
                                    <div id="infoDesc">
                                        <h3>Descripción: </h3>
                                        <p>${dato[0].desc_infraccion}</p>
                                    </div>
                                </div>`;
            cont.innerHTML = textoHTML;
        });
    } catch (e) {
        alert(e)
    }
}

const cerrar = () => {
    ventana.classList.remove("uno");
    ventana.className = ("dos");
    let cont = document.getElementById("contendorInfo");
    let textoHTML = `   <a href="#app" class="salir" id="salir" onclick="cerrar();"><i class="bi bi-x-lg"></i></a>
                                    <h2>Información de inmovilización</h2>
                                    <div class="cuadros">
                                    <div><h3>Matricula: </h3><p>...</p></div>
                                    <div><h3>Ciudad: </h3><p>...</p></div>
                                    <div><h3>Fecha de Vigencia: </h3><p>...</p></div>
                                    <div><h3>Código: </h3><p>...</p></div>
                                    <div id="infoDesc">
                                        <h3>Descripción: </h3>
                                        <p>...</p>
                                    </div>
                                </div>`;
    cont.innerHTML = textoHTML;
}

const formatoPorcentaje = (valor) => {
    return valor.toLocaleString('es-CL', {style:'percent', minimumFractionDigits:1})
}

var vectorCiudades = [];
var contar = {};
var contador = [];
var cant = 0;
let puesto1 = document.getElementById("puesto1");
let puesto2 = document.getElementById("puesto2");
let puesto3 = document.getElementById("puesto3");
const cargarCiudades = () => {
    const todos = getAll().then(dato =>{
        dato.forEach((elemento, index) => {
            let cadena = String(elemento.ciudad_inmovilizacion);
            if(!vectorCiudades.includes(cadena)){
                vectorCiudades.push(cadena);
            }
            
            cant = index+1;
            contar[cadena] = contar[cadena] ? contar[cadena]+1 : 1;
        });
         console.log(vectorCiudades);
         console.log(contar);
         for(let i=0;i<vectorCiudades.length;i++){
             contador.push(contar[vectorCiudades[i]]);
         }
         console.log(contador.sort((a, b) => {return b - a}));

         let porcentaje = 0;
         for(let i=0;i<vectorCiudades.length;i++){
             if(contador[0]==contar[vectorCiudades[i]]){
                 porcentaje = contador[0]/cant;
                 puesto1.innerHTML = `
                                    <h4>${vectorCiudades[i]}</h4>
                                    <h3>${formatoPorcentaje(porcentaje)}</h3>
                                    <p>Con <span>${contador[0]}</span> inmovilizaciones.</p>`;
             }
             if(contador[1]==contar[vectorCiudades[i]]){
                 porcentaje = contador[1]/cant;
                 puesto2.innerHTML = `
                                    <h4>${vectorCiudades[i]}</h4>
                                    <h3>${formatoPorcentaje(porcentaje)}</h3>
                                    <p>Con <span>${contador[1]}</span> inmovilizaciones.</p>`;
             }
             if(contador[2]==contar[vectorCiudades[i]]){
                 porcentaje = contador[3]/cant;
                 puesto3.innerHTML = `
                                    <h4>${vectorCiudades[i]}</h4>
                                    <h3>${formatoPorcentaje(porcentaje)}</h3>
                                    <p>Con <span>${contador[2]}</span> inmovilizaciones.</p>`;
             }
         }
    });
}
 

var vectorInfracciones = [];
var contarInfra = {};
var contadorIn = [];
let puesto11 = document.getElementById("puesto11");
let puesto22 = document.getElementById("puesto22");
let puesto33 = document.getElementById("puesto33");
const cargarInfracciones = () => {
    const todos = getAll().then(dato =>{
        dato.forEach((elemento, index) => {
            let cadena = String(elemento.desc_infraccion);
            if(!vectorInfracciones.includes(cadena)){
                vectorInfracciones.push(cadena);
            }
            
            cant = index+1;
            contarInfra[cadena] = contarInfra[cadena] ? contarInfra[cadena]+1 : 1;
        });
         console.log(vectorInfracciones);
         console.log(contarInfra);
         for(let i=0;i<vectorInfracciones.length;i++){
             contadorIn.push(contarInfra[vectorInfracciones[i]]);
         }
         console.log(contadorIn.sort((a, b) => {return b - a}));

         let porcentaje = 0;
         for(let i=0;i<vectorInfracciones.length;i++){
             if(contadorIn[0]==contarInfra[vectorInfracciones[i]]){
                 porcentaje = contadorIn[0]/cant;
                 puesto11.innerHTML = `
                                    <h4>${vectorInfracciones[i]}</h4>
                                    <h3>${formatoPorcentaje(porcentaje)}</h3>
                                    <p>Con <span>${contadorIn[0]}</span> infraccioones realizadas.</p>`;
             }
             if(contadorIn[1]==contarInfra[vectorInfracciones[i]]){
                 porcentaje = contadorIn[1]/cant;
                 puesto22.innerHTML = `
                                    <h4>${vectorInfracciones[i]}</h4>
                                    <h3>${formatoPorcentaje(porcentaje)}</h3>
                                    <p>Con <span>${contadorIn[1]}</span> infracciones realizadas.</p>`;
             }
             if(contadorIn[2]==contarInfra[vectorInfracciones[i]]){
                 porcentaje = contadorIn[3]/cant;
                 puesto33.innerHTML = `
                                    <h4>${vectorInfracciones[i]}</h4>
                                    <h3>${formatoPorcentaje(porcentaje)}</h3>
                                    <p>Con <span>${contadorIn[2]}</span> infracciones realizadas.</p>`;
             }
         }
    });
}