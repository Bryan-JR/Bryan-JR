import java.util.ArrayList;
public class ArrayVendidos {
    
    ArrayList<Vendido> Vendidos;
    
    public ArrayVendidos(){
        Vendidos = new ArrayList<>();
    }
    
    public int getTam(){
        return Vendidos.size();
    }
    
    public boolean estaVacia(){
        return Vendidos.isEmpty();
    }
    
    public void limpiarArray(){
        Vendidos.clear();
    }
    
    public Vendido Objeto(int pos){
        return Vendidos.get(pos);
    }
    
    public void AgregarVendidos(Vendido v){
        Vendidos.add(v);
    }
}
