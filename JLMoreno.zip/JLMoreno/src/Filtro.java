import java.io.*;
import java.util.StringTokenizer;

public class Filtro extends Producto{
    
    protected String codigo;
    protected String tipo;
    protected String marca;
    private File file;
    private String dir, user;
    
    public Filtro(){
        super();
        codigo = "";
        tipo = "";
        marca = "";
        user = System.getProperty("user.dir");
        dir=user+"\\Filtros.txt";
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    public String getDir(){
        return dir;
    }
    
    public String datosFiltro(Filtro f){
        return super.datos(f)+sep
               +f.getCodigo()+sep
               +f.getTipo()+sep
               +f.getMarca();
    }
    
    public void EditarArchivo(Filtro info) throws IOException { 
        file = new File(getDir());
        BufferedWriter escribir;
        
        if(file.exists()){
            escribir = new BufferedWriter(new FileWriter(file, true));
            escribir.write(datosFiltro(info));
            escribir.newLine();
        } else {
            escribir = new BufferedWriter(new FileWriter(file));
            escribir.write(datosFiltro(info));
            escribir.newLine();
        }
        escribir.close();
    }
    
    public void LimpiarArchivo() throws IOException{
        file = new File(getDir());
        BufferedWriter limpiar = new BufferedWriter(new FileWriter(file));
        limpiar.write("");
    }
    
    public ArrayFiltro DatosGuardados() throws FileNotFoundException, IOException {
         String datos = "";
         ArrayFiltro info = new ArrayFiltro();
         Filtro f;
         BufferedReader buffer = new BufferedReader(new FileReader(getDir()));
         
         while((datos = buffer.readLine()) != null){
             StringTokenizer dato = new StringTokenizer(datos, this.sep);
             while(dato.hasMoreElements()){
                 f = new Filtro();
                 f.setCantidad(Integer.parseInt(dato.nextElement().toString()));
                 f.setValorUnidad(Double.parseDouble(dato.nextElement().toString()));
                 f.setValorVenta(Double.parseDouble(dato.nextElement().toString()));
                 f.setCodigo(dato.nextElement().toString());
                 f.setTipo(dato.nextElement().toString());
                 f.setMarca(dato.nextElement().toString());
                 info.AgregarFiltro(f);
             }
         }
         buffer.close();
         return info;
    }
}
