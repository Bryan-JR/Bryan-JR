import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class ArrayFiltro {
    
    ArrayList<Filtro> Filtros;
    DecimalFormat forma = (DecimalFormat) NumberFormat.getCurrencyInstance();
    
    public ArrayFiltro(){
        Filtros = new ArrayList<>();
        forma.setMinimumFractionDigits(0);
    }
    
    public int getTam(){
        return Filtros.size();
    }
    
    public boolean estaVacia(){
        return Filtros.isEmpty();
    }
    
    public void limpiarArray(){
        Filtros.clear();
    }
    
    public Filtro Objeto(int pos){
        return Filtros.get(pos);
    }
    
    public void AgregarFiltro(Filtro f){
        Filtros.add(f);
    }
    
    public void EliminarFiltro(Filtro f){
        Filtros.remove(f);
    }
    
    public void Cambiar(int P1,int P2){
        Filtro dato;
        dato=Objeto(P1);
        Filtros.set(P1,Objeto(P2));
        Filtros.set(P2,dato);
    }
    
    public void OrdenarCodigo(){
     int i, j, d;
     d=getTam()/2;
     while(d>=1){
         for(i=d;i<getTam();i++){
             j=i;
             while(j-d>=0){
                 int comparacion = Objeto(j-d).getCodigo().compareTo(Objeto(j).getCodigo());
                 if(comparacion>0){
                     Cambiar(j-d, j);
                     j=j-d;
                 } else {
                     break;
                 }
             } 
         }d=d/2;
     }
 }
    
    public void disminuirCantidad(Filtro f, int cantidad){
        if (f.getCantidad()>=cantidad){
            f.setCantidad(f.getCantidad() - cantidad);
        } else {
            JOptionPane.showMessageDialog(null, "Solo hay "+f.getCantidad()
                    +" de "
                    +f.getCodigo(), 
                    "INFORMACIÓN", 
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    public void editarCantidad(Filtro f){
        try {
            int nCantidad = Integer.parseInt(JOptionPane.showInputDialog(null, 
                    "<html>"
                    +"<body>"
                       +"<p style=\"font-weight:500;\">Ingrese la nueva cantidad para:</p>"
                       +"<h4 style=\"color:0348BD;\">"+f.getCodigo()+"</h4>"
                       +"<p style=\"font-weight:500;\">La cantidad actual es: <span style=\"color:0348BD;\">"+f.getCantidad()+"</span></p>"
                    +"</body>"
                    +"</html>",
                    "ACTUALIZACIÓN",
                    JOptionPane.PLAIN_MESSAGE));
            if (nCantidad>0){
                f.setCantidad(nCantidad);
                JOptionPane.showMessageDialog(null, "<html><h4 style=\"color:30BD03;\">¡Se actualizó correctamente!</h4></html>");
            } else {
                JOptionPane.showMessageDialog(null, "<html><h4 style=\"color:D01A04;\">La cantidad debe ser mayor a 0.</h4></html>", "", JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "<html><h4 style=\"color:D01A04;\">No se pudo actualizar la información.</h4></html>", "", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void editarPUnidad(Filtro f){
        try {
            String pUnidad = JOptionPane.showInputDialog(null, 
                    "<html>"
                    +"<body>"
                       +"<p style=\"font-weight:500;\">Ingrese el nuevo precio de unidad para:</p>"
                       +"<h4 style=\"color:0348BD;\">"+f.getCodigo()+"</h4>"
                       +"<p style=\"font-weight:500;\">El precio de unidad actual es: <span style=\"color:0348BD;\">"+forma.format(Double.parseDouble(f.getValorUnidad()))+"</span></p>"
                    +"</body>"
                    +"</html>",
                    "ACTUALIZACIÓN",
                    JOptionPane.PLAIN_MESSAGE);
                f.setValorUnidad(pUnidad.replaceAll("[. ,]", ""));
                JOptionPane.showMessageDialog(null, "<html><h4 style=\"color:30BD03;\">¡Se actualizó correctamente!</h4></html>");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "<html><h4 style=\"color:D01A04;\">No se pudo actualizar la información.</h4></html>", "", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void editarPVenta(Filtro f){
        try {
            String pVenta = JOptionPane.showInputDialog(null,
                    "<html>"
                    +"<body>"
                       +"<p style=\"font-weight:500;\">Ingrese el nuevo precio de venta para:</p>"
                       +"<h4 style=\"color:0348BD;\">"+f.getCodigo()+"</h4>"
                       +"<p style=\"font-weight:500;\">El precio de venta actual es: <span style=\"color:0348BD;\">"+forma.format(Double.parseDouble(f.getValorVenta()))+"</span></p>"
                    +"</body>"
                    +"</html>",
                    "ACTUALIZACIÓN",
                    JOptionPane.PLAIN_MESSAGE);
                f.setValorVenta(pVenta.replaceAll("[. ,]", ""));
                JOptionPane.showMessageDialog(null, "<html><h4 style=\"color:30BD03;\">¡Se actualizó correctamente!</h4>");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "<html><h4 style=\"color:D01A04;\">No se pudo actualizar la información.</h4></html>", "", JOptionPane.ERROR_MESSAGE);
        }
    }
}
