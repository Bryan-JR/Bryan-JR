import java.util.ArrayList;
import javax.swing.JOptionPane;


public class ArrayFiltro {
    
    ArrayList<Filtro> Filtros;
    
    public ArrayFiltro(){
        Filtros = new ArrayList<>();
    }
    
    public int getTam(){
        return Filtros.size();
    }
    
    public Filtro Objeto(int pos){
        return Filtros.get(pos);
    }
    
    public void AgregarFiltro(Filtro f){
        Filtros.add(f);
    }
    
    public void EliminarFiltro(Filtro f){
        Filtros.remove(f);
    }
    
    public void Cambiar(int P1,int P2){
        Filtro dato;
        dato=Objeto(P1);
        Filtros.set(P1,Objeto(P2));
        Filtros.set(P2,dato);
    }
    
    public void OrdenarCódigo(){
     int i, j, d;
     d=getTam()/2;
     while(d>=1){
         for(i=d;i<getTam();i++){
             j=i;
             while(j-d>=0){
                 int comparacion = Objeto(j-d).getCodigo().compareTo(Objeto(j).getCodigo());
                 if(comparacion>0){
                     Cambiar(j-d, j);
                     j=j-d;
                 } else {
                     break;
                 }
             } 
         }d=d/2;
     }
 }
    
    public void disminuirCantidad(Filtro f, int cantidad){
        if (f.getCantidad()>=cantidad){
            f.setCantidad(f.getCantidad() - cantidad);
        } else {
            JOptionPane.showMessageDialog(null, "Solo hay "+f.getCantidad()
                    +" de "
                    +f.getCodigo(), 
                    "INFORMACIÓN", 
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
