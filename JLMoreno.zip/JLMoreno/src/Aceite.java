import java.io.*;
import java.util.StringTokenizer;

public class Aceite extends Producto{
    
    protected String insumo;
    protected String descripcion;
    private File file;
    private String dir, user;
    
    public Aceite(){
        super();
        insumo = "";
        descripcion = "";
        user = System.getProperty("user.dir");
        dir=user+"\\Aceites.txt";
    }

    public String getInsumo() {
        return insumo;
    }

    public void setInsumo(String insumo) {
        this.insumo = insumo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    public String getDir(){
        return dir;
    }
  
    public String datosAceite(Aceite a){
        return super.datos(a)+sep
               +a.getInsumo()+sep
               +a.getDescripcion();
    }
    
    public void EditarArchivo(Aceite info) throws IOException { 
        file = new File(getDir());
        BufferedWriter escribir;
        
        if(file.exists()){
            escribir = new BufferedWriter(new FileWriter(file, true));
            escribir.write(datosAceite(info));
            escribir.newLine();
        } else {
            escribir = new BufferedWriter(new FileWriter(file));
            escribir.write(datosAceite(info));
            escribir.newLine();
        }
        escribir.close();
    }
    
    public void LimpiarArchivo() throws IOException{
        file = new File(getDir());
        BufferedWriter limpiar = new BufferedWriter(new FileWriter(file));
        limpiar.write("");
    }
    
    public ArrayAceite DatosGuardados() throws FileNotFoundException, IOException {
         String datos = "";
         ArrayAceite info = new ArrayAceite();
         Aceite a;
         BufferedReader buffer = new BufferedReader(new FileReader(getDir()));
         
         while((datos = buffer.readLine()) != null){
             StringTokenizer dato = new StringTokenizer(datos, this.sep);
             while(dato.hasMoreElements()){
                 a = new Aceite();
                 a.setCantidad(Integer.parseInt(dato.nextElement().toString()));
                 a.setValorUnidad(Double.parseDouble(dato.nextElement().toString()));
                 a.setValorVenta(Double.parseDouble(dato.nextElement().toString()));
                 a.setInsumo(dato.nextElement().toString());
                 a.setDescripcion(dato.nextElement().toString());
                 info.AgregarAceite(a);
             }
         }
         buffer.close();
         return info;
    }
}
