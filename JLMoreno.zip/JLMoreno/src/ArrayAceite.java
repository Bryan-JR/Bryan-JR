import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class ArrayAceite {
    
    ArrayList<Aceite> Aceites;
    DecimalFormat forma = (DecimalFormat) NumberFormat.getCurrencyInstance();
    
    public ArrayAceite(){
        Aceites = new ArrayList<>();
        forma.setMinimumFractionDigits(0);
    }
    
    public int getTam(){
        return Aceites.size();
    }
    
    public boolean estaVacia(){
        return Aceites.isEmpty();
    }
    
    public void limpiarArray(){
        Aceites.clear();
    }
    
    public Aceite Objeto(int pos){
        return Aceites.get(pos);
    }
    
    public void AgregarAceite(Aceite a){
        Aceites.add(a);
    }
    
    public void EliminarAceite(Aceite a){
        Aceites.remove(a);
    }
    
    public void Cambiar(int P1,int P2){
        Aceite dato;
        dato=Objeto(P1);
        Aceites.set(P1,Objeto(P2));
        Aceites.set(P2,dato);
    }
    
    public void OrdenarInsumo(){
     int i, j, d;
     d=getTam()/2;
        while(d>=1){
            for(i=d;i<getTam();i++){
                j=i;
                while(j-d>=0){
                    int comparacion = Objeto(j-d).getInsumo().compareTo(Objeto(j).getInsumo());
                    if(comparacion>0){
                        Cambiar(j-d, j);
                        j=j-d;
                    } else {
                        break;
                    }
                } 
            }d=d/2;
        }
    }
    
    public void disminuirCantidad(Aceite a, int cantidad){
        if (a.getCantidad()>=cantidad){
            a.setCantidad(a.getCantidad() - cantidad);
        }
    }
    
    public void editarCantidad(Aceite a){
        try {
            int nCantidad = Integer.parseInt(JOptionPane.showInputDialog(null, 
                    "<html>"
                    +"<body>"
                       +"<p style=\"font-weight:500;\">Ingrese la nueva cantidad para:</p>"
                       +"<h4 style=\"color:0348BD;\">"+a.getDescripcion()+"</h4>"
                       +"<p style=\"font-weight:500;\">La cantidad actual es: <span style=\"color:0348BD;\">"+a.getCantidad()+"</span></p>"
                    +"</body>"
                    +"</html>",
                    "ACTUALIZACIÓN",
                    JOptionPane.PLAIN_MESSAGE));
            if (nCantidad>0){
                a.setCantidad(nCantidad);
                JOptionPane.showMessageDialog(null, "<html><h4 style=\"color:30BD03;\">¡Se actualizó correctamente!</h4></html>");
            } else {
                JOptionPane.showMessageDialog(null, "<html><h4 style=\"color:D01A04;\">La cantidad debe ser mayor a 0.</h4></html>", "", JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "<html><h4 style=\"color:D01A04;\">No se pudo actualizar la información.</h4></html>", "", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void editarPUnidad(Aceite a){
        try {
            String pUnidad = JOptionPane.showInputDialog(null, 
                    "<html>"
                    +"<body>"
                       +"<p style=\"font-weight:500;\">Ingrese el nuevo precio de unidad para:</p>"
                       +"<h4 style=\"color:0348BD;\">"+a.getDescripcion()+"</h4>"
                       +"<p style=\"font-weight:500;\">El precio de unidad actual es: <span style=\"color:0348BD;\">"+forma.format(Double.parseDouble(a.getValorUnidad()))+"</span></p>"
                    +"</body>"
                    +"</html>",
                    "ACTUALIZACIÓN",
                    JOptionPane.PLAIN_MESSAGE);
                a.setValorUnidad(pUnidad.replaceAll("[. ,]", ""));
                JOptionPane.showMessageDialog(null, "<html><h4 style=\"color:30BD03;\">¡Se actualizó correctamente!</h4></html>");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "<html><h4 style=\"color:D01A04;\">No se pudo actualizar la información.</h4></html>", "", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void editarPVenta(Aceite a){
        try {
            String pVenta = JOptionPane.showInputDialog(null,
                    "<html>"
                    +"<body>"
                       +"<p style=\"font-weight:500;\">Ingrese el nuevo precio de venta para:</p>"
                       +"<h4 style=\"color:0348BD;\">"+a.getDescripcion()+"</h4>"
                       +"<p style=\"font-weight:500;\">El precio de venta actual es: <span style=\"color:0348BD;\">"+forma.format(Double.parseDouble(a.getValorVenta()))+"</span></p>"
                    +"</body>"
                    +"</html>",
                    "ACTUALIZACIÓN",
                    JOptionPane.PLAIN_MESSAGE);
                a.setValorVenta(pVenta.replaceAll("[. ,]", ""));
                JOptionPane.showMessageDialog(null, "<html><h4 style=\"color:30BD03;\">¡Se actualizó correctamente!</h4>");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "<html><h4 style=\"color:D01A04;\">No se pudo actualizar la información.</h4></html>", "", JOptionPane.ERROR_MESSAGE);
        }
    }
}
