import java.util.ArrayList;
import javax.swing.JOptionPane;


public class ArrayAceite {
    
    ArrayList<Aceite> Aceites;
    
    public ArrayAceite(){
        Aceites = new ArrayList<>();
    }
    
    public int getTam(){
        return Aceites.size();
    }
    
    public Aceite Objeto(int pos){
        return Aceites.get(pos);
    }
    
    public void AgregarAceite(Aceite a){
        Aceites.add(a);
    }
    
    public void EliminarAceite(Aceite a){
        Aceites.remove(a);
    }
    
    public void Cambiar(int P1,int P2){
        Aceite dato;
        dato=Objeto(P1);
        Aceites.set(P1,Objeto(P2));
        Aceites.set(P2,dato);
    }
    
    public void OrdenarInsumo(){
     int i, j, d;
     d=getTam()/2;
     while(d>=1){
         for(i=d;i<getTam();i++){
             j=i;
             while(j-d>=0){
                 int comparacion = Objeto(j-d).getInsumo().compareTo(Objeto(j).getInsumo());
                 if(comparacion>0){
                     Cambiar(j-d, j);
                     j=j-d;
                 } else {
                     break;
                 }
             } 
         }d=d/2;
     }
 }
    
    public void disminuirCantidad(Aceite a, int cantidad){
        if (a.getCantidad()>=cantidad){
            a.setCantidad(a.getCantidad() - cantidad);
        } else {
            JOptionPane.showMessageDialog(null, "Solo hay "+a.getCantidad()
                    +" de "
                    +a.getDescripcion(), 
                    "INFORMACIÓN", 
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
