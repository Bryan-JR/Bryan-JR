public class Producto {
    
    private int cantidad;
    private double valorUnidad;
    private double valorVenta;
    static String sep = ";";
    
    public Producto(){
        cantidad=0;
        valorUnidad=0;
        valorVenta=0;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getValorUnidad() {
        return valorUnidad;
    }

    public void setValorUnidad(double valorUnidad) {
        this.valorUnidad = valorUnidad;
    }

    public double getValorVenta() {
        return valorVenta;
    }

    public void setValorVenta(double valorVenta) {
        this.valorVenta = valorVenta;
    }
    
    public String datos(Producto p){
        return  p.getCantidad()+sep
               +p.getValorUnidad()+sep
               +p.getValorVenta();
    }
}
