public class Producto {
    
    private int cantidad;
    private String valorUnidad;
    private String valorVenta;
    static String sep = ";";
    
    public Producto(){
        cantidad=0;
        valorUnidad="";
        valorVenta="";
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getValorUnidad() {
        return valorUnidad;
    }

    public void setValorUnidad(String valorUnidad) {
        this.valorUnidad = valorUnidad;
    }

    public String getValorVenta() {
        return valorVenta;
    }

    public void setValorVenta(String valorVenta) {
        this.valorVenta = valorVenta;
    }
    
    public String datos(Producto p){
        return  p.getCantidad()+sep
               +p.getValorUnidad()+sep
               +p.getValorVenta();
    }
}
