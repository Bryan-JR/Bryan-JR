import java.io.*;
import java.util.StringTokenizer;

public class Vendido {
    
    private String producto;
    private String costo;
    private String fecha;
    private File file;
    String sep = ";";
    private String user, dir;
    
    public Vendido(){
        producto = "";
        costo = "";
        fecha = "";
        user = System.getProperty("user.dir");
        dir=user+"\\Vendidos.txt";
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public String getCosto() {
        return costo;
    }

    public void setCosto(String costo) {
        this.costo = costo;
    }
    
    public String getFecha(){
        return fecha;
    }
    
    public void setFecha(String fecha){
        this.fecha = fecha;
    }
    
    public String getDir(){
        return dir;
    }
    
    public String datosVendido(Vendido v){
        return v.getProducto()+sep
               +v.getCosto()+sep
               +v.getFecha();
    }
    
    public void EditarArchivo(Vendido info) throws IOException { 
        file = new File(getDir());
        BufferedWriter escribir;
        
        if(file.exists()){
            escribir = new BufferedWriter(new FileWriter(file, true));
            escribir.write(datosVendido(info));
            escribir.newLine();
        } else {
            escribir = new BufferedWriter(new FileWriter(file));
            escribir.write(datosVendido(info));
            escribir.newLine();
        }
        escribir.close();
    }
    
    public void LimpiarArchivo() throws IOException{
        file = new File(getDir());
        BufferedWriter limpiar = new BufferedWriter(new FileWriter(file));
        limpiar.write("");
    }
    
    public ArrayVendidos DatosGuardados() throws FileNotFoundException, IOException {
         String datos = "";
         ArrayVendidos info = new ArrayVendidos();
         Vendido v;
         BufferedReader buffer = new BufferedReader(new FileReader(getDir()));
         
         while((datos = buffer.readLine()) != null){
             StringTokenizer dato = new StringTokenizer(datos, this.sep);
             while(dato.hasMoreElements()){
                 v = new Vendido();
                 v.setProducto(dato.nextElement().toString());
                 v.setCosto(dato.nextElement().toString());
                 v.setFecha(dato.nextElement().toString());
                 info.AgregarVendidos(v);
             }
         }
         buffer.close();
         return info;
    }
}
