let muestra = () => {
    let tipo = Number(document.getElementById("tipo").value);
    console.log(tipo);
    if(tipo==0){
        document.getElementById('datosEmpresa').classList.remove('down');
    } else {
        document.getElementById('datosEmpresa').classList.add('down');
    }
}

const inputCorreo = document.getElementById("correo");
const inputContraseña = document.getElementById("contraseña");
const inputContraseñaConfir = document.getElementById("contraseñaconfi");
const boton = document.getElementById('terminar');

const tieneMayuscula = (mensaje) => {
    const upperLower = "ABCDEFGHIJKLMNÑOPQRSTUVWXYZ";

  for(let i=0;i<upperLower.length;i++){
    if (mensaje.indexOf(upperLower.charAt(i))!=-1) {
        return true;
    }
  }
  return false;
}

const tieneNumero = (mensaje) =>{
    const number = "1234567890";
    for(let i=0;i<number.length;i++){
    if (mensaje.indexOf(number.charAt(i))!=-1) {
        return true;
    }
  }
  return false;
}

const tieneCaracter = (mensaje) =>{
    const especiales = String(".-,_<>#$%&/@=+*?¡¿?!");
    for(let i=0;i<especiales.length;i++){
    if (mensaje.indexOf(especiales.charAt(i))!=-1) {
        return true;
    }
  }
  return false;
}




const info1 = document.getElementById("info1");
const info2 = document.getElementById("info2");
const info3 = document.getElementById("info3");
const info4 = document.getElementById("info4");
const icon1 = document.getElementById("icon1");
const icon2 = document.getElementById("icon2");
const icon3 = document.getElementById("icon3");
const icon4 = document.getElementById("icon4");

const mensajeContraseña = ()=>{
    let pass = inputContraseña.value;
    if(pass.length>=8){
        info1.style = "color: #0cba06";
        inputContraseña.style = "border: 2px solid #0cba06";
        icon1.classList.remove("bi-x-circle");
        icon1.classList.add("bi-check-circle");
        inputContraseñaConfir.disabled = false;
    } else {
        info1.style = "color: #ba0606";
        icon1.classList.remove("bi-check-circle");
        icon1.classList.add("bi-x-circle");
        inputContraseñaConfir.disabled = true;
    }
    if(tieneMayuscula(pass)){
        info2.style = "color: #0cba06";
        icon2.classList.remove("bi-x-circle");
        icon2.classList.add("bi-check-circle");
        inputContraseñaConfir.disabled = false;
    } else {
        info2.style = "color: #ba0606";
        icon2.classList.remove("bi-check-circle");
        icon2.classList.add("bi-x-circle");
        inputContraseñaConfir.disabled = true;
    }

    if(tieneNumero(pass)){
        info3.style = "color: #0cba06";
        icon3.classList.remove("bi-x-circle");
        icon3.classList.add("bi-check-circle");
        inputContraseñaConfir.disabled = false;
    } else {
        info3.style = "color: #ba0606";
        icon3.classList.remove("bi-check-circle");
        icon3.classList.add("bi-x-circle");
        inputContraseñaConfir.disabled = true;
    }

    if(tieneCaracter(pass)){
        info4.style = "color: #0cba06";
        icon4.classList.remove("bi-x-circle");
        icon4.classList.add("bi-check-circle");
        inputContraseñaConfir.disabled = false;
    } else {
        info4.style = "color: #ba0606";
        icon4.classList.remove("bi-check-circle");
        icon4.classList.add("bi-x-circle");
    }

    if(pass===""){
        info1.style = "color: #ba0606";
        info2.style = "color: #ba0606";
        info3.style = "color: #ba0606";
        info4.style = "color: #ba0606";
        inputContraseña.style = "border: 2px solid #ba0606";
        icon1.classList.remove("bi-check-circle");
        icon1.classList.add("bi-x-circle");
        icon2.classList.remove("bi-check-circle");
        icon2.classList.add("bi-x-circle");
        icon3.classList.remove("bi-check-circle");
        icon3.classList.add("bi-x-circle");
        icon4.classList.remove("bi-check-circle");
        icon4.classList.add("bi-x-circle");
        inputContraseñaConfir.disabled = true;
    }
};

let verificarContra = () =>{
    if(inputContraseña.value === inputContraseñaConfir.value){
        inputContraseñaConfir.style = "border: 2px solid #0cba06";
        boton.disabled = false;
    } else {
        inputContraseñaConfir.style = "border: 2px solid #ba0606";
        boton.disabled = true;
    }
}

let verificarCorreo = () =>{
    if(inputCorreo.value != "" && inputCorreo.value.includes('@') && inputCorreo.value.includes('.')){
        inputCorreo.style = "border: 2px solid #0cba06";
        inputContraseña.disabled = false;
    } else {
        inputCorreo.style = "border: 2px solid #ba0606";
        inputContraseña.true = false;
    }
}