let tarjetas = document.querySelectorAll('.tarjeta');
mostrarTarjetas = () =>{
    let scroll = document.documentElement.scrollTop;
    for(let i = 0; i < tarjetas.length; i++){
        let altura = tarjetas[i].offsetTop - 350;
        if(altura < scroll){
                tarjetas[i].classList.remove('desaparecer');
                if(i<3){
                    tarjetas[i].classList.add('moverLado-'+i);
                } else {
                    tarjetas[i].classList.add('moverLado-'+(i-3));
                }
        } else {
            tarjetas[i].classList.add('desaparecer');
        }
    }
}

window.addEventListener('scroll', mostrarTarjetas);

let escribir = (str) =>{
    let array = str.split('');
    let i = 0;
    let texto = setInterval(() => {
        if (i==13) {
            document.getElementById('title').innerHTML += '<span id="name" class="pag moverLado-1"></span>';
        }
        if(i<13){
            document.getElementById('title').innerHTML += array[i];
        } else {
            document.getElementById('name').innerHTML += array[i];
        }
        i++
        if(i==str.length){
            clearInterval(texto);
        }
    }, 60);
}

escribir('Bienvenido a MarkFlex');

const user = document.getElementById('usuario');
const pass = document.getElementById('contraseña');
const iniciar = document.getElementById('iniciar');

activar = () =>{
    if (user!='' && pass!='') {
        iniciar.disabled = false;
    } else {
        iniciar.disabled = true;
    }
}