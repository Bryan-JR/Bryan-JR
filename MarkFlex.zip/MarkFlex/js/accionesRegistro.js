let muestra = () => {
    let tipo = Number(document.getElementById("tipo").value);
    console.log(tipo);
    if(tipo==0){
        document.getElementById('datosEmpresa').classList.remove('down');
    } else {
        document.getElementById('datosEmpresa').classList.add('down');
    }
}