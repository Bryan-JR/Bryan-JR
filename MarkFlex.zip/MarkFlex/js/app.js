let tarjetas = document.querySelectorAll('.tarjeta');
mostrarTarjetas = () =>{
    let scroll = document.documentElement.scrollTop;
    for(let i = 0; i < tarjetas.length; i++){
        let altura = tarjetas[i].offsetTop - 350;
        if(altura < scroll){
                tarjetas[i].classList.remove('desaparecer');
                if(i<3){
                    tarjetas[i].classList.add('moverLado-'+i);
                } else {
                    tarjetas[i].classList.add('moverLado-'+(i-3));
                }
        } else {
            tarjetas[i].classList.add('desaparecer');
        }
    }
}

window.addEventListener('scroll', mostrarTarjetas);