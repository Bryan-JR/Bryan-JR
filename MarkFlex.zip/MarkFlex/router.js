const express = require('express');
const router = express.Router();

const conexion = require('./database/db')

//MOSTRAR TODOS LOS DATOS
router.get('/', (req, res)=>{
           // nos dirige al index, la página principal
           res.render('index', {mensaje:''});
});

//CREAR LOS REGISTROS
router.get('/registrar', (req, res)=>{
    res.render('registrar', {confirmacion:'', mensaje: ''});
});

router.post('/inicio', (req, res) => {
    const correoUser = req.body.usuario;
    const contraseña = req.body.contraseña;
    conexion.query(`CALL comprobarCuenta("${correoUser}", "${contraseña}");`, (error, result) => {
        let resultado  = Object.values(JSON.parse(JSON.stringify(result[0])));
        console.log(resultado[0].valor);
        let msg = resultado[0].valor;
        if( msg == 'empresa' || msg == 'personal'){
            res.redirect('/home/'+msg);
        } else if (msg == "incorrecta"){
            res.render('index', {mensaje:"La contraseña es incorrecta."});
        } else if(msg == 'no existe') {
            res.render('index', {mensaje:"La cuenta no existe. <br><a href='/registrar'> regitrate aquí </a>"});
        } else {
            res.redirect('/');
        }
            
    });
})

router.get('/home/:tipo', (req, res) =>{
    const tipo = req.params.tipo;
    conexion.query('SELECT  * FROM Convocatorias ORDER BY fechaCreado DESC;', (error, results) =>{
        if (tipo == 'empresa') {
            res.render('markflex', 
            {
                convocatorias:results,
                rutas: `<a href="#" class="opcion">
                <div><i class="bi bi-stack"></i></div>
                    Mis convocatorias
                </a>
                <a href="#" class="opcion">
                    <div><i class="bi bi-people-fill"></i></div>
                    Mis grupos
                </a>
                <a href="#" class="opcion">
                    <div><i class="bi bi-piggy-bank-fill"></i></div>
                    Mi saldo
                </a>`,
                nav: `
                    <li><i class="bi bi-person-fill"></i></li>
                    <li><i class="bi bi-plus-lg"></i></li>
                    <li><i class="bi bi-chat-fill"></i></li>
                    <li><i class="bi bi-bell-fill"></i></li>
                    <li id="mas"<i class="bi bi-caret-down-fill"></i></li>`
            });
        } else if (tipo == 'personal'){
            res.render('markflex', 
            {
                convocatorias:results,
                rutas: `
                <a href="#" class="opcion"> 
                    <div><i class="bi bi-person-workspace"></i></div>
                    Mis trabajos
                </a>
                <a href="#" class="opcion">
                    <div><i class="bi bi-people-fill"></i></div>
                    Mis grupos
                </a>
                <a href="#" class="opcion">
                    <div><i class="bi bi-piggy-bank-fill"></i></div>
                    Mi saldo
                </a>`,
                nav: `
                    <li><i class="bi bi-person-fill"></i></li>
                    <li><i class="bi bi-chat-fill"></i></li>
                    <li><i class="bi bi-bell-fill"></i></li>
                    <li id="mas"<i class="bi bi-caret-down-fill"></i></li>`
            });
        }
    })
});

// EDITAR LOS REGISTROS
router.get('/edit/:id', (req,res)=>{    
    const id = req.params.id;
    conexion.query('SELECT * FROM users WHERE id=?',[id] , (error, results) => {
        if (error) {
            throw error;
        }else{            
            res.render('edit.ejs', {user:results[0]});            
        }        
    });
});


const crud = require('./controllers/crud');
router.post('/guardar', crud.guardar);


module.exports = router;