const mysql = require('mysql');
const { isRegExp } = require('util/types');

const conexion = mysql.createConnection({
    host: 'securitybox.cmllg7rqx1ny.us-east-1.rds.amazonaws.com',
    user: 'admin',
    password: '1234567890',
    database: 'MarkFlex',
    port: 3306
});

conexion.connect((error)=>{
    if(error){
        console.error('El error de conexion es: '+error);
        return
    }
    console.log('¡Conectado a la Base de Datos MySQL!');
})

module.exports = conexion;