const conexion = require('../database/db');

exports.guardar = (req, res)=>{
    const tipoCuenta = req.body.tipoCuenta;
   const nombre = req.body.nombre;
   const apellido = req.body.apellido;
   const tipoDocumento = req.body.documentos;
   const nDocumento = req.body.nDocumento;
   const fechaNa = req.body.fecha;
   const genero = req.body.genero;
   const usuario = req.body.usuario;
   const correo = req.body.correo;
   const contraseña = req.body.contraseña;
   let nombreEmpresa  = '';
   if(tipoCuenta==0){
       nombreEmpresa = req.body.nombreEmpresa;
   }
   conexion.query(`CALL nuevoRegistro(${tipoCuenta} , ${nDocumento} , '${nombre}' , '${apellido}', '${tipoDocumento}', '${fechaNa}', '${genero}', '${usuario}', '${correo}', '${contraseña}', '${nombreEmpresa}')`, (error, results)=>{
    console.log(results);
    let resultado  = Object.values(JSON.parse(JSON.stringify(results[0])));
    console.log(resultado[0].valor);
    let msg = resultado[0].valor;
         if(msg == 'Usuario existe'){
             res.render('registrar', {confirmacion:'', mensaje:`<section class="msgComprobar" id="msgEstado">
                                                                    El usuario ya existe.
                                                                </section>`});
         } else if (msg == 'Correo Existe'){
             res.render('registrar', {confirmacion:'', mensaje:`<section class="msgComprobar" id="msgEstado">
                                                                    El correo ya existe.
                                                                </section>`});
         } else if(msg == 'Datos guardados') {
            res.render('registrar', {confirmacion:`<section class="ventanaConfirm" id="ventanaConfirm">
                                                        <div class="formatoConfirm">
                                                            <h2>¡Registro Exitoso!</h2>
                                                            <p class="msgConfirm">Es momento para que comiences a explorar todos los beneficios que ofrece <span class="pag">MarkFlex</span> .</p>
                                                            <a href="/" class="boton">Volver al inicio</a>
                                                        </div>
                                                    </section>`
                                                , mensaje: ''});
         } else {
             res.render('registrar', {confirmacion:'', mensaje:`<section class="msgComprobar" id="msgEstado">
                                                                    verifique la información ingresada.
                                                                </section>`});
         }
   })
};

exports.update = (req, res)=>{
    const id = req.body.id;
    const user = req.body.user;
    const rol = req.body.rol;
    conexion.query('UPDATE users SET ? WHERE id = ?',[{user:user, rol:rol}, id], (error, results)=>{
        if(error){
            console.log(error);
        }else{           
            res.redirect('/');         
        }
});
};