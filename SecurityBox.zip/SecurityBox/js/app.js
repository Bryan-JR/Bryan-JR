cliente = "https://61e1dafc3050a10017682028.mockapi.io/cliente";
cuentaSecurityBox = "https://61e1dafc3050a10017682028.mockapi.io/cuentaSB";
cuentas = "https://61e1dafc3050a10017682028.mockapi.io/cuentas";
aplicaciones = "https://61e1dafc3050a10017682028.mockapi.io/aplicaciones";

getCuentasSB = async (email) => {
    try {
        const respuesta = await fetch(this.cuentaSecurityBox+"?correo="+email);
        console.log("Funciona");
        if(respuesta.status == 200){
            let json = await respuesta.json();3
            return json;
        }
    } catch (error) {
        alert(error);
    }
}

getCuentas = async (id) => {
    try {
        const respuesta = await fetch(this.cuentas+"?idSB="+id);

        if(respuesta.status == 200){
            let json = await respuesta.json();
            return json;
        }
    } catch (error) {
        alert(error);
    }
}
getAplicacion = async (idApp) => {
    try {
        const respuesta = await fetch(this.aplicaciones+"?idApp="+idApp);
        if(respuesta.status == 200){
            let json = await respuesta.json();
            return json;
        }
    } catch (error) {
        alert(error);
    }
}

let iniciar = document.getElementById("iniciarSesion");
let store = localStorage;
let entradaCorreo = "";
let entradaContraseña = "";
let msg = document.getElementById("msg");
let codigoCuenta = 0;
let user = "";

let getIniciar = () => {
    entradaCorreo = document.getElementById("correo").value.replace("@","-");
    entradaContraseña = document.getElementById("contraseña").value;
    getCuentasSB(entradaCorreo).then((dato)=>{
        if(dato.length>0){
            dato.forEach(element => {
                codigoCuenta = Number(element.idSB);
                user = String(element.usuario);
                let contraseña = String(element.contrasena);
                if(entradaContraseña==contraseña){
                    store.setItem("idSB", codigoCuenta);
                    store.setItem("user", user);
                    location.href =  "html/securityBox.html";
                } else {
                    msg.classList.remove("down");
                    msg.className = "mensajeError up";
                }
            });
        } else {
            msg.innerHTML = "La cuenta no está registrada <a href='html/registro.html'>registrate aquí</a>";
            msg.classList.remove("down");
            msg.className = "mensajeError up";
        }
    });
};

let cargarDatos=()=>{
    codigoCuenta = Number(store.getItem("idSB"));
    user = store.getItem("user");
    getCuentas(codigoCuenta).then(dato => {
        const TablaContenedor = document.getElementById("tabla");
        let TextoHTML = `
                            <tr>
                                <th>Item</th>
                                <th>Sitio</th>
                                <th>Correo / Usuario</th>
                                <th>Contraseña</th>
                            </tr>`;
            let i = 1;
            dato.forEach((element) => {
                let result = Number(element.idSB);
                let i = Number(element.idApp);
                getAplicacion(i).then(data => {
                    let nombreApp = "";
                    let urlApp = "";
                    let j = 0;
                    data.forEach(r => {
                        nombreApp = r.nombre;
                        urlApp = r.url;
                        j = Number(r.idApp);
                        if(result===codigoCuenta && i===j){
                            TextoHTML = TextoHTML + `
                            <tr>
                                <td>${i++}</td>
                                <td><a href="${urlApp}" target="_blank">${nombreApp}</a></td>
                                <td>${element.Correo}</td>
                                <td>${element.Contrasena}</td>
                            </tr> `
                        }
                        
                    });
                    document.getElementById("ident").innerHTML = '<i class="bi bi-person-circle">'+user;
                    TablaContenedor.innerHTML = TextoHTML;
                });
            }); 
                                        
    });
}

let cargarApp = ()=>{
    getAplicacion(" ").then(dato=>{
        let texto = "";
        dato.forEach((r, i)=>{
            texto += `<option value="${i+1}" style="font-weight:600;">${r.nombre}</option>`;
        });
        texto += '<option value="nuevo" style="font-weight:600; color: #ba0606; background-color:#9b9fa198;">Agregar nuevo</option>'
        document.getElementById("sitio").innerHTML = texto;
    });
}

let isReload = () => {
    if (store.length==0 && codigoCuenta==0){
        location.href = '../index.html';
    }
}