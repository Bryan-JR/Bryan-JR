package com.prueba.demo.interfaceService;
import java.util.*;
import com.prueba.demo.modelo.Persona;

public interface IPersonaService {
	public List<Persona> listar();
	public Optional<Persona>ListarId(int id);
	public int save(Persona p);
	public void delete(int id);
}
