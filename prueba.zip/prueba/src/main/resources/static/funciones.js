eliminar = (id) =>{
	swal({
	  title: "¿Está seguro de eliminar?",
	  text: "Se borrará permanentemente de la base de datos!",
	  icon: "warning",
	  buttons: true,
	  dangerMode: true,
	})
	.then((OK) => {
	  if (OK) {
		$.ajax({
			url:"/eliminar/"+id,
			success: (res) => {
				console.log(res);
			}
		});
	    swal("¡El dato fue eliminado!", {
	      icon: "success",
	    }).then((ok)=>{
				if(ok){
					location.href="/listar";
				}
			});
	  } else {
	    swal("El dato no se eliminó.");
	  }
	});
}